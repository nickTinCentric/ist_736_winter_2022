# -*- coding: utf-8 -*-
"""
Created on Thu Dec 20 21:20:56 2018

@author: profa
"""

## This is a comment
## Next, to make sure everything
## Works - we will print "hello world"
print("Hello World")
## To test this - save it - give it a name
## MAKE SURE YOU SEE/CONTROL where it saves
## Then run it using the green run button above
